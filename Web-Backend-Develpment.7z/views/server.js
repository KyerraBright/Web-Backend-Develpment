/* ******************************************
 * This server.js file is the primary file of the 
 * application. It is used to control the project.
 *******************************************/
/* ***********************
 * Require Statements
 *************************/
const express = require("express")
const expressLayouts = require("express-ejs-layouts")
const env = require("dotenv").config()
const app = express()
const static = require("./routes/static")
const baseController = require("./Controllers/baseController")
const invroute = require("./routes/inventoryRoute")


/* ***********************
 * View Engine and Templates
 *************************/
app.use(expressLayouts)
app.set("layout", "/layouts/layout.ejs") // not at views root

/* ***********************
 * Routes
 *************************/
app.use(static)
app.get("/", function(req, res) {
  res.render("layouts/layout.ejs")
})
app.use(invroute)

/* ***********************
 * Local Server Information
 * Values from .env (environment) file
 *************************/
const port = process.env.PORT
const host = process.env.HOST

/* ***********************
 * Log statement to confirm server operation
 *************************/
app.listen(port, () => {
  console.log(`app listening on ${host}:${port}`)
})
